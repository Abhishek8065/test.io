// API Endpoints
const apiEndpoints = {
    countries: "https://localhost:7097/api/Countries/GetAllStates",
    states: "https://localhost:7097/api/States/GetAllStates",
    cities: "https://localhost:7097/api/Cities/GetAllCities"
};

// DOM Elements
const countrySelect = document.getElementById("country");
const stateSelect = document.getElementById("state");
const citySelect = document.getElementById("city");

// Fetch and populate countries on page load
document.addEventListener("DOMContentLoaded", () => {
    fetch(apiEndpoints.countries)
        .then(response => response.json())
        .then(data => populateDropdown(countrySelect, data, "Select Country"))
        .catch(error => console.error("Error fetching countries:", error));
});

// Handle country selection and fetch states
countrySelect.addEventListener("change", () => {
    const countryId = countrySelect.value;
    if (countryId) {
        fetch(`${apiEndpoints.states}?countryId=${countryId}`)
            .then(response => response.json())
            .then(data => {
                populateDropdown(stateSelect, data, "Select State");
                stateSelect.disabled = false;
                citySelect.disabled = true;
                citySelect.innerHTML = `<option value="">Select City</option>`; // Reset cities
            })
            .catch(error => console.error("Error fetching states:", error));
    } else {
        stateSelect.disabled = true;
        citySelect.disabled = true;
    }
});

// Handle state selection and fetch cities
stateSelect.addEventListener("change", () => {
    const stateId = stateSelect.value;
    if (stateId) {
        fetch(`${apiEndpoints.cities}?stateId=${stateId}`)
            .then(response => response.json())
            .then(data => {
                populateDropdown(citySelect, data, "Select City");
                citySelect.disabled = false;
            })
            .catch(error => console.error("Error fetching cities:", error));
    } else {
        citySelect.disabled = true;
    }
});

// Populate dropdown helper function
function populateDropdown(dropdown, items, placeholder) {
    dropdown.innerHTML = `<option value="">${placeholder}</option>`;
    items.forEach(item => {
        const option = document.createElement("option");
        option.value = item.id; // Assuming each item has an "id" property
        option.textContent = item.name; // Assuming each item has a "name" property
        dropdown.appendChild(option);
    });
}
