﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task.Data;
using Task.Model;
using Task.Models;

namespace Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CitiesController : ControllerBase
    {
        private readonly AppDBContext _DbContext;

        public CitiesController(AppDBContext appDBContext)
        {
            _DbContext=appDBContext;
        }


        [HttpGet]
        [Route("GetAllCities")]
        public async Task<IActionResult> GetAllCities()
        {
            try
            {
                var result = await _DbContext.Cities.ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

        }

        [HttpPost]
        [Route("AddCities")]
        public async Task<IActionResult> AddCities(AddCities addCities)
        {
            var cities = new City
            {
                Cityname = addCities.Cityname,
                IsActive = true,

            };

            await _DbContext.Cities.AddAsync(cities);
            await _DbContext.SaveChangesAsync();
            return Ok(cities);

        }

        [HttpDelete]
        [Route("DeleteCities")]

        public async Task<IActionResult> DeleteCities(int Id)
        {
            try
            {
                var result = await _DbContext.Cities.FindAsync(Id);
                if (result == null)
                {
                    return BadRequest("Id is NOt Found");
                }
                _DbContext.Cities.Remove(result);
                await _DbContext.SaveChangesAsync();
                return Ok(result);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
