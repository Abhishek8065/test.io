﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task.Data;
using Task.Model;
using Task.Models;

namespace Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountriesController : ControllerBase
    {
        private readonly AppDBContext _DbContext;

        public CountriesController(AppDBContext appDBContext)
        {
            _DbContext = appDBContext;
        }

        [HttpGet]
        [Route("GetAllStates")]
        public async Task<IActionResult> GetAllStates()
        {
            try
            {
                var result = await _DbContext.Countries.ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

        }

        [HttpPost]
        [Route("AddCountries")]
        public async Task<IActionResult> AddCountries(AddCountries addCountries)
        {
            var Countries = new Country
            {
                Countryname = addCountries.Countryname,
                IsActive = true,

            };

            await _DbContext.Countries.AddAsync(Countries);
            await _DbContext.SaveChangesAsync();
            return Ok(Countries);

        }

        [HttpDelete]
        [Route("DeleteCountries")]

        public async Task<IActionResult> DeleteCountries(int Id)
        {
            try
            {
                var result = await _DbContext.Countries.FindAsync(Id);
                if (result == null)
                {
                    return BadRequest("Id is NOt Found");
                }
                _DbContext.Countries.Remove(result);
                await _DbContext.SaveChangesAsync();
                return Ok(result);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
