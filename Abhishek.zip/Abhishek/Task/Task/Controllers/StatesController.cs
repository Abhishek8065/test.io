﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task.Data;
using Task.Model;
using Task.Models;

namespace Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatesController : ControllerBase
    {
        private readonly AppDBContext _DbContext;

        public StatesController(AppDBContext appDBContext)
        {
            _DbContext=appDBContext;
        }


        [HttpGet]
        [Route("GetAllStates")]
        public async Task<IActionResult> GetAllStates()
        {
            try
            {
                var result = await _DbContext.States.ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

        }

        [HttpPost]
        [Route("AddStates")]
        public async Task<IActionResult> AddStates(AddStates addStates)
        {
            var states = new State
            {
                Statename = addStates.Statename,
                IsActive = true,

            };

            await _DbContext.States.AddAsync(states);
            await _DbContext.SaveChangesAsync();
            return Ok(states);

        }

        [HttpDelete]
        [Route("DeleteStates")]

        public async Task<IActionResult> DeleteStates(int Id)
        {
            try
            {
                var result = await _DbContext.States.FindAsync(Id);
                if (result == null)
                {
                    return BadRequest("Id is NOt Found");
                }
                _DbContext.States.Remove(result);
                await _DbContext.SaveChangesAsync();
                return Ok(result);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}
