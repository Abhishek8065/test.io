﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task.Data;
using Task.Model;
using Task.Models;

namespace Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly AppDBContext _DbContext;

        public UsersController(AppDBContext appDBContext)
        {
            _DbContext = appDBContext;
        }

        [HttpGet]
        [Route("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                // Get all users and include the related Country, State, and City names
                var users = await _DbContext.Users
                    .Join(_DbContext.Countries, u => u.Countryid, c => c.Id, (u, c) => new { u, c.Countryname })
                    .Join(_DbContext.States, x => x.u.Stateid, s => s.Id, (x, s) => new { x.u, x.Countryname, s.Statename })
                    .Join(_DbContext.Cities, x => x.u.Cityid, ct => ct.Id, (x, ct) => new
                    {
                        x.u.Id,
                        x.u.Username,
                        x.u.Password,
                        CountryName = x.Countryname, // Country name
                        StateName = x.Statename, // State name
                        CityName = ct.Cityname, // City name
                        x.u.IsActive,
                        x.u.CreatedDate,
                        x.u.CreateBy,
                        x.u.UpdateDate,
                        x.u.UpdatedBy
                    })
                    .ToListAsync();

                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPost]
        [Route("AddUsers")]
        public async Task<IActionResult> AddUsers(AddUsers addUsers)
        {
            var users = new User
            {
                Username = addUsers.Username,
                Password= addUsers.Password,
                Countryid= addUsers.Countryid,
                Stateid=addUsers.Stateid,
                Cityid =addUsers.Cityid,
                IsActive= true,
                CreatedDate= DateTime.Now,

            };

            await _DbContext.Users.AddAsync(users);
            await _DbContext.SaveChangesAsync();
            return Ok();

        }

        [HttpPut]
        [Route("UpdateUsers")]
        public async Task<IActionResult> UpdateUser(UpdateUsers updateUsers)
        {
            try
            {
                var result = await _DbContext.Users.FindAsync(updateUsers.Id);

                if (result == null)
                {
                    return BadRequest("User NOT Found");
                }

                result.Username = updateUsers.Username;
                result.Password = updateUsers.Password;
                result.Countryid = updateUsers.Countryid;
                result.Stateid = updateUsers.Stateid;
                result.Cityid = updateUsers.Cityid;
                result.IsActive = updateUsers.IsActive;
                result.CreateBy = updateUsers.CreateBy;
                result.UpdateDate = DateTime.Now;
                result.UpdatedBy = updateUsers.UpdatedBy;
                await _DbContext.SaveChangesAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

         [HttpDelete]
        [Route("DeleteUsers")]

        public async Task<IActionResult> DeleteUsers(int Id)
        {
            try
            {
                var result = await _DbContext.Users.FindAsync(Id);
                if (result == null)
                { 
                 return BadRequest("Id is NOt Found");
                }
                _DbContext.Users.Remove(result);
                await _DbContext.SaveChangesAsync();
                return Ok(result);

            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}
