﻿using System.ComponentModel.DataAnnotations;

namespace Task.Model
{
    public class City
    {
        [Key]
        public int Id { get; set; }
        public string Cityname { get; set; }
        public bool IsActive { get; set; }
    }
}
