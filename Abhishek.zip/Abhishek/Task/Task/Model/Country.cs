﻿using System.ComponentModel.DataAnnotations;

namespace Task.Model
{
    public class Country
    {
        [Key]
        public int Id { get; set; }
        public string Countryname { get; set; }
        public bool IsActive { get; set; }
    }
}
