﻿using System.ComponentModel.DataAnnotations;

namespace Task.Model
{
    public class State
    {
        [Key]
        public int Id { get; set; }
        public string Statename { get; set; }
        public bool IsActive {  get; set; } 
        
    }
}
