﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Task.Model
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Countryid { get; set; } // Foreign key
        public int Stateid { get; set; }   // Foreign key
        public int Cityid { get; set; }    // Foreign key
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreateBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public int? UpdatedBy { get; set; }
        [NotMapped]
        public string Countrynames { get; set; }
        [NotMapped]
        public string Statenames { get; set; }
        [NotMapped]
        public string Citynames { get; set; }

    }
}
