﻿namespace Task.Models
{
    public class AddCities
    {
        public string Cityname { get; set; }
        public bool IsActive { get; set; }
    }
}
