﻿namespace Task.Models
{
    public class AddCountries
    {
        public string Countryname { get; set; }
        public bool IsActive { get; set; }
    }
}
