﻿namespace Task.Models
{
    public class AddStates
    {
        public string Statename { get; set; }
        public bool IsActive { get; set; }
    }
}
