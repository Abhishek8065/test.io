﻿namespace Task.Models
{
    public class AddUsers
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int Countryid { get; set; } // Foreign key
        public int Stateid { get; set; }   // Foreign key
        public int Cityid { get; set; }    // Foreign key
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
      
    }
}

