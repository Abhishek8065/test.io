﻿namespace Task.Models
{
    public class UpdateUsers
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Countryid { get; set; } // Foreign key
        public int Stateid { get; set; }   // Foreign key
        public int Cityid { get; set; }    // Foreign key
        public bool IsActive { get; set; }
        public int? CreateBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public int? UpdatedBy { get; set; }
    }
}
